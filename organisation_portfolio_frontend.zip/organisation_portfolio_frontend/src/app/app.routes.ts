import { Routes } from '@angular/router';
import { UserLayoutComponent } from './pages/user/user-layout/main/user-layout.component';
import { HomepageComponent } from './pages/user/homepage/main/homepage.component';

export const routes: Routes = [
    {
        path: '',
        component: HomepageComponent,
    }
];
