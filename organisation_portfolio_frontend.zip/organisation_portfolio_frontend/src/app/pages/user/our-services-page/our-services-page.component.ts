import { Component } from '@angular/core';

@Component({
  selector: 'app-our-services-page',
  imports: [],
  templateUrl: './our-services-page.component.html',
  styleUrl: './our-services-page.component.scss'
})
export class OurServicesPageComponent {

}
