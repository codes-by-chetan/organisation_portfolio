import { Component } from '@angular/core';

@Component({
  selector: 'app-download-profile',
  imports: [],
  templateUrl: './download-profile.component.html',
  styleUrl: './download-profile.component.scss'
})
export class DownloadProfileComponent {

}
